package com.nielsen.book.poc_shared.root;

public final class BuildEnvironmentVariables {

    public static final String VAR_SELENIUM_GRID_HOST_2_53_1 = //
        "SELENIUM_GRID_HOST_2_53_1";
    public static final String VAR_SELENIUM_GRID_PORT_2_53_1 = //
        "SELENIUM_GRID_PORT_2_53_1";

    public static final String VAR_SELENIUM_GRID_HOST_4_1_1 = //
        "SELENIUM_GRID_HOST_4_1_1";
    public static final String VAR_SELENIUM_GRID_PORT_4_1_1 = //
        "SELENIUM_GRID_PORT_4_1_1";

    public static final String VAR_SELENIUM_GRID_HOST_3_14_0 = //
        "SELENIUM_GRID_HOST_3_14_0";
    public static final String VAR_SELENIUM_GRID_PORT_3_14_0 = //
        "SELENIUM_GRID_PORT_3_14_0";

    public static final String VAR_SELENIUM_GRID_HOST_3_141_59 = //
        "SELENIUM_GRID_HOST_3_141_59";
    public static final String VAR_SELENIUM_GRID_PORT_3_141_59 = //
        "SELENIUM_GRID_PORT_3_141_59";

    private BuildEnvironmentVariables() {
    }
}
