package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.server;

import java.io.File;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared.GenerateJSONFilterCriteriaHelper;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared.GenerateJSONFilterCriteriaOutputEncoding;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared.GenerateJSONFilterCriteriaOutputType;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputEncoding;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputType;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputVersion;

public final class GenerateJSONFilterCriteriaServletHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenerateJSONFilterCriteriaServletHelper.class);

    public interface FiltersForServerDecoder {

        String decode(String clientCriteria) throws Exception;
    }

    public static void generateJSONFilterCriteria(final GenerateJSONFilterCriteriaInputType inputType,
                                                  final String input,
                                                  final GenerateJSONFilterCriteriaInputEncoding inputEncoding,
                                                  final GenerateJSONFilterCriteriaInputVersion inputVersion,
                                                  final FiltersForServerDecoder filtersForServerDecoder) {

        try {

            LOGGER.info( //
                        "At generateJSONFilterCriteria():\ninputType= {}\ninputEncoding= {}\ninputVersion: {}\ninput: {}", //
                        inputType, //
                        inputEncoding, //
                        inputVersion, //
                        input //
            );

            // Export JSON for use by server-side tests
            final GenerateJSONFilterCriteriaOutputEncoding outputEncoding =
                GenerateJSONFilterCriteriaOutputEncoding.valueOf(inputEncoding.name());
            final File outputFolder = GenerateJSONFilterCriteriaHelper.getOutputFolder(outputEncoding);
            FileUtils.forceMkdir(outputFolder);
            LOGGER.info("outputFolder is {}", outputFolder);
            final GenerateJSONFilterCriteriaOutputType outputType =
                GenerateJSONFilterCriteriaOutputType.valueOf(inputType.name());
            final File outputFile =
                FileUtils.getFile(outputFolder,
                                  inputVersion.name(),
                                  outputType.name() +
                                      GenerateJSONFilterCriteriaHelper.GENERATE_JSON_FILTER_CRITERIA_FILE_SUFFIX);
            LOGGER.info("outputFile is {}", outputFile.getAbsolutePath());
            FileUtils.deleteQuietly(outputFile);

            // Convert to server criteria
            final String filtersForServer = filtersForServerDecoder.decode(input);

            // Write filter to output file
            FileUtils.write(outputFile, filtersForServer, StandardCharsets.ISO_8859_1);

        } catch (Exception cause) {

            LOGGER.error("generateJSONFilterCriteria() failed", cause);

            throw new RuntimeException(cause);
        }
    }

    private GenerateJSONFilterCriteriaServletHelper() {
    }
}
