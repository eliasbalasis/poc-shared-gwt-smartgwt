package com.nielsen.book.poc_shared.tools.selenium;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.exec.environment.EnvironmentUtils;

public final class SeleniumSupport {

    public static final String VAR_CHROME_DRIVER_PATH_2_53_1 = "SELENIUM_CHROME_DRIVER_PATH_2_53_1";
    public static final String VAR_CHROME_BINARY_PATH_2_53_1 = "SELENIUM_CHROME_BINARY_PATH_2_53_1";

    public static final String VAR_FIREFOX_DRIVER_PATH_2_53_1 = "SELENIUM_FIREFOX_DRIVER_PATH_2_53_1";
    public static final String VAR_FIREFOX_BINARY_PATH_2_53_1 = "SELENIUM_FIREFOX_BINARY_PATH_2_53_1";

    public static final String VAR_EDGE_DRIVER_PATH_4_1_1 = "SELENIUM_EDGE_DRIVER_PATH_4_1_1";

    public static final String VAR_CHROME_DRIVER_PATH_3_14_0 = "SELENIUM_CHROME_DRIVER_PATH_3_14_0";
    public static final String VAR_CHROME_BINARY_PATH_3_14_0 = "SELENIUM_CHROME_BINARY_PATH_3_14_0";

    public static final String VAR_CHROME_DRIVER_PATH_3_141_59 = "SELENIUM_CHROME_DRIVER_PATH_3_141_59";
    public static final String VAR_CHROME_BINARY_PATH_3_141_59 = "SELENIUM_CHROME_BINARY_PATH_3_141_59";

    public static final String FORCE_DRIVER_EXECUTABLE = "SELENIUM_FORCE_DRIVER_EXECUTABLE";

    private static final SeleniumSupport singleton = new SeleniumSupport();

    public static SeleniumSupport getDefault() {

        return singleton;
    }

    private Map<String, String> environment;

    public boolean forceDriverExecutable() throws IOException {

        // Force use of driver executable (if configured)
        final boolean forceDriverExecutable;
        initialize();
        if (this.environment.containsKey(FORCE_DRIVER_EXECUTABLE)) {
            forceDriverExecutable = Boolean.valueOf(this.environment.get(FORCE_DRIVER_EXECUTABLE)).booleanValue();
        } else {
            forceDriverExecutable = false;
        }

        return forceDriverExecutable;
    }

    private void initialize() throws IOException {

        if (this.environment == null) {

            this.environment = EnvironmentUtils.getProcEnvironment();
        }
    }

    private SeleniumSupport() {
    }
}
