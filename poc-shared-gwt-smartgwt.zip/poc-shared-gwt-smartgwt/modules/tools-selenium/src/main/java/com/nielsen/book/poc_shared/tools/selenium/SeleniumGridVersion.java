package com.nielsen.book.poc_shared.tools.selenium;

public enum SeleniumGridVersion {

                                 SELENIUM_2_53_1,
                                 SELENIUM_4_1_1,
                                 SELENIUM_3_14_0,
                                 SELENIUM_3_141_59
}
