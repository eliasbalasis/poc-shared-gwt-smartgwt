package com.nielsen.book.poc_shared.tools.selenium;

import java.io.IOException;
import java.net.URL;
import java.util.Map;

import org.apache.commons.exec.environment.EnvironmentUtils;

import com.nielsen.book.poc_shared.root.BuildEnvironmentVariables;

public final class SeleniumGridSupport {

    private static final SeleniumGridSupport singleton = new SeleniumGridSupport();

    public static SeleniumGridSupport getDefault() {

        return singleton;
    }

    private Map<String, String> environment;

    public URL getSeleniumGridURL(final SeleniumGridVersion version) throws IOException {

        initialize();

        final String host;
        final int port;

        switch (version) {

        case SELENIUM_2_53_1:

            host = //
                this.environment.get( //
                                     BuildEnvironmentVariables.VAR_SELENIUM_GRID_HOST_2_53_1 //
                );
            port = //
                Integer.valueOf( //
                                this.environment.get(BuildEnvironmentVariables.VAR_SELENIUM_GRID_PORT_2_53_1) //
                ).intValue();

            break;

        case SELENIUM_4_1_1:

            host = //
                this.environment.get( //
                                     BuildEnvironmentVariables.VAR_SELENIUM_GRID_HOST_4_1_1 //
                );
            port = //
                Integer.valueOf( //
                                this.environment.get(BuildEnvironmentVariables.VAR_SELENIUM_GRID_PORT_4_1_1) //
                ).intValue();

            break;

        case SELENIUM_3_14_0:

            host = //
                this.environment.get( //
                                     BuildEnvironmentVariables.VAR_SELENIUM_GRID_HOST_3_14_0 //
                );
            port = //
                Integer.valueOf( //
                                this.environment.get(BuildEnvironmentVariables.VAR_SELENIUM_GRID_PORT_3_14_0) //
                ).intValue();

            break;

        case SELENIUM_3_141_59:

            host = //
                this.environment.get( //
                                     BuildEnvironmentVariables.VAR_SELENIUM_GRID_HOST_3_141_59 //
                );
            port = //
                Integer.valueOf( //
                                this.environment.get(BuildEnvironmentVariables.VAR_SELENIUM_GRID_PORT_3_141_59) //
                ).intValue();

            break;

        default:

            throw new IllegalArgumentException("Unknown Selenium Grid: " + version.name());
        }

        return new URL("http", host, port, "/wd/hub");
    }

    private void initialize() throws IOException {

        if (this.environment == null) {

            this.environment = EnvironmentUtils.getProcEnvironment();
        }
    }

    private SeleniumGridSupport() {
    }
}
