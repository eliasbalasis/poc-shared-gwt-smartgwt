package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared;

public final class GenerateJSONFilterCriteriaProperties {

    public static final String PROJECT_LOCATION_SMARTGWT_6_1_GWT_2_8_2 = "project.location-6.1-2.8.2";
    public static final String PROJECT_LOCATION_SMARTGWT_13_0_GWT_2_9_0 = "project.location-13.0-2.9.0";

    private GenerateJSONFilterCriteriaProperties() {
    }
}
