package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public final class GenerateJSONFilterCriteriaHelper {

    public static final String GENERATE_JSON_FILTER_CRITERIA_FOLDER_PARENT = "generated";

    public static final String GENERATE_JSON_FILTER_CRITERIA_FILE_SUFFIX = ".json";

    public static final File
           getOutputFolder(final GenerateJSONFilterCriteriaOutputEncoding outputEncoding) throws IOException {

        final File outputFolder =
            FileUtils.getFile(GenerateJSONFilterCriteriaHelper.GENERATE_JSON_FILTER_CRITERIA_FOLDER_PARENT,
                              GenerateJSONFilterCriteriaHelper.class.getSimpleName(),
                              outputEncoding.name());
        return outputFolder;
    }

    private GenerateJSONFilterCriteriaHelper() {
    }
}
