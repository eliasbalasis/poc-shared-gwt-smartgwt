package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared;

public enum GenerateJSONFilterCriteriaOutputVersion {
                                                     SMARTGWT_6_1_GWT_2_8_2(GenerateJSONFilterCriteriaProperties.PROJECT_LOCATION_SMARTGWT_6_1_GWT_2_8_2),
                                                     SMARTGWT_13_0_GWT_2_9_0(GenerateJSONFilterCriteriaProperties.PROJECT_LOCATION_SMARTGWT_13_0_GWT_2_9_0);
    ;

    private final String property;

    public String getProperty() {

        return property;
    }

    private GenerateJSONFilterCriteriaOutputVersion(final String property) {

        this.property = property;
    }
}
