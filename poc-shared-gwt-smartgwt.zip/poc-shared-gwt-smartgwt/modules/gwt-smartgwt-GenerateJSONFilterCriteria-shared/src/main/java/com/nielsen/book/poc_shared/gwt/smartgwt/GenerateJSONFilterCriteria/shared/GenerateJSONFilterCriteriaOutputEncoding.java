package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.shared;

public enum GenerateJSONFilterCriteriaOutputEncoding {
                                                      TO_JSON,
                                                      AS_STRING
}
