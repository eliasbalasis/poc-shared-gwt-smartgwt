package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

import java.io.File;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.exec.environment.EnvironmentUtils;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.isomorphic.webdriver.SmartClientChromeDriver;
import com.isomorphic.webdriver.SmartClientWebDriver;

public class SeleniumTest extends AbstractSeleniumTest<SmartClient_13_0_WebDriverContainer> {

    @Override
    protected Iterable<Capabilities> capabilitiesList() {

        // "Chrome" browser version (94.0.4606.61)
        // bundled with "Selenium" of "SmartGWT 13.0"
        // is incompatible with "Nielsen Client Platform"
        //
        final DesiredCapabilities capabilities = new DesiredCapabilities(new ChromeOptions());
        capabilities.setJavascriptEnabled(true);
        capabilities.setPlatform(Platform.LINUX);
        return Arrays.asList(capabilities);
    }

    @Override
    protected SmartClient_13_0_WebDriverContainer webDriverContainer(final Capabilities capabilities) throws Throwable {

        final SmartClientWebDriver webDriver;

        final Map<String, String> environment = EnvironmentUtils.getProcEnvironment();

        if (capabilities.getBrowserName().equals(BrowserType.CHROME)) {

            // "Selenium Driver" executable
            // https://chromedriver.storage.googleapis.com/index.html
            final String chromeDriverPath = environment.get(SeleniumSupport.VAR_CHROME_DRIVER_PATH_3_141_59);
            System.setProperty("webdriver.chrome.driver", chromeDriverPath);

            // Requires "Chrome" 94.0.4606.61
            // same as the remote "Chrome" browser version
            // bundled with "Selenium" of "SmartGWT 13.0"
            // https://www.chromium.org/getting-involved/download-chromium
            //
            // Requires "Selenium Driver" executable version 94.0.4606.61
            //
            if (environment.containsKey(SeleniumSupport.VAR_CHROME_BINARY_PATH_3_141_59)) {

                final String pathToChromeBinary = environment.get(SeleniumSupport.VAR_CHROME_BINARY_PATH_3_141_59);
                final ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.setBinary(new File(pathToChromeBinary).getAbsolutePath());
                webDriver = new SmartClientChromeDriver(chromeOptions);

            } else {

                webDriver = null;
            }

        } else {

            webDriver = null;
        }

        final SmartClient_13_0_WebDriverContainer webDriverContainer =
            new SmartClient_13_0_WebDriverContainer(webDriver);
        return webDriverContainer;
    }

    @Override
    protected void configureWebDriver(final Capabilities capabilities,
                                      final SmartClient_13_0_WebDriverContainer webDriverContainer) {

        webDriverContainer.setBaseUrl(BASE_URL);
    }

    @Override
    protected void navigate(final SmartClient_13_0_WebDriverContainer webDriverContainer) {

        webDriverContainer.navigateToPath(PATH);
    }

    @Test
    public void run() throws Throwable {

        main();
    }
}
