package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.server;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.isomorphic.criteria.AdvancedCriteria;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteria;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputEncoding;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputType;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputVersion;

public class GenerateJSONFilterCriteriaServlet extends RemoteServiceServlet implements GenerateJSONFilterCriteria {

    private static final long serialVersionUID = 1557660652569663472L;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void generateJSONFilterCriteria(final GenerateJSONFilterCriteriaInputType inputType,
                                           final String input,
                                           final GenerateJSONFilterCriteriaInputEncoding inputEncoding,
                                           final GenerateJSONFilterCriteriaInputVersion inputVersion) {

        final GenerateJSONFilterCriteriaServletHelper.FiltersForServerDecoder filtersForServerDecoder =
            new GenerateJSONFilterCriteriaServletHelper.FiltersForServerDecoder() {

                @Override
                public String decode(String clientCriteria) throws Exception {

                    final AdvancedCriteria advanced = AdvancedCriteria.decodeClientCriteria(clientCriteria);
                    final String filterForServer =
                        GenerateJSONFilterCriteriaServlet.this.objectMapper.writeValueAsString(advanced);
                    return filterForServer;
                }
            };

        GenerateJSONFilterCriteriaServletHelper.generateJSONFilterCriteria(inputType,
                                                                           input,
                                                                           inputEncoding,
                                                                           inputVersion,
                                                                           filtersForServerDecoder);
    }
}
