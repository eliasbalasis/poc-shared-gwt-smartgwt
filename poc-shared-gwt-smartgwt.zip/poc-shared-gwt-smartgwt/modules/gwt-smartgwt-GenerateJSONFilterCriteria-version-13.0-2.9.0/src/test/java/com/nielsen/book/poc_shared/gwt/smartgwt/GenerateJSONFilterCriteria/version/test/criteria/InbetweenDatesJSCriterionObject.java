package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria;

import com.google.gwt.core.client.JavaScriptObject;

public class InbetweenDatesJSCriterionObject extends JavaScriptObject {

    protected InbetweenDatesJSCriterionObject() {
        super();
    }

    public final native void setFieldName(final String fieldName) /*-{
		this.fieldName = fieldName;
    }-*/;

    public final native void setOperator(final String operator) /*-{
		this.operator = operator;
    }-*/;

    public final native String getFieldName(final String fieldName) /*-{
		return this.fieldName;
    }-*/;

    public final native String getOperator() /*-{
		return this.operator;
    }-*/;

    public final native void setStart(final RelativeDateAsStartRangeJSObject start) /*-{
		this.start = start;
    }-*/;

    public final native String getStart() /*-{
		return this.start;
    }-*/;

    public final native void setEnd(final RelativeDateAsEndRangeJSObject end) /*-{
		this.end = end;
    }-*/;

    public final native String getEnd() /*-{
		return this.end;
    }-*/;

}
