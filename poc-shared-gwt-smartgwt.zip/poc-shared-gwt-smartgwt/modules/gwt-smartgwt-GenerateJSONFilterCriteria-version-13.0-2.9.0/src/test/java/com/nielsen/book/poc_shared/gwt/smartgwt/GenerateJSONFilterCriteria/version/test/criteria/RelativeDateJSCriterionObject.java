package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria;

import com.google.gwt.core.client.JavaScriptObject;

public class RelativeDateJSCriterionObject extends JavaScriptObject {

    protected RelativeDateJSCriterionObject() {
        super();
    }

    public final native void setFieldName(final String fieldName) /*-{
		this.fieldName = fieldName;
    }-*/;

    public final native void setOperator(final String operator) /*-{
		this.operator = operator;
    }-*/;

    public final native void setValue(final RelativeDateJSObject value) /*-{
		this.value = value;
    }-*/;

    public final native String getFieldName(final String fieldName) /*-{
		return this.fieldName;
    }-*/;

    public final native String getOperator() /*-{
		return this.operator;
    }-*/;

    public final native String getValue() /*-{
		return this.value;
    }-*/;

}
