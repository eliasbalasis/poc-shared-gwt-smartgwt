package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria;

import com.google.gwt.core.client.JavaScriptObject;

public class RelativeDateJSObject extends JavaScriptObject {

    protected RelativeDateJSObject() {
        super();
    }

    public final native void setConstructor(final String _constructor) /*-{
		this._constructor = _constructor;
    }-*/;

    public final native void setValue(final String value) /*-{
		this.value = value;
    }-*/;

    public final native String getConstructor() /*-{
		return this._constructor;
    }-*/;

    public final native String getValue() /*-{
		return this.value;
    }-*/;
}
