package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria;

import com.google.gwt.core.client.JavaScriptObject;

public class RelativeDateAsEndRangeJSObject extends JavaScriptObject {

    protected RelativeDateAsEndRangeJSObject() {
        super();
    }

    public final native void setConstructor(final String _constructor) /*-{
		this._constructor = _constructor;
    }-*/;

    public final native String getConstructor() /*-{
		return _constructor;
    }-*/;

    public final native void setRangePosition(final String rangePosition) /*-{
		this.rangePosition = rangePosition;
    }-*/;

    public final native String getRangePosition() /*-{
		return rangePosition;
    }-*/;

    public final native void setValue(final String value) /*-{
		this.value = value;
    }-*/;

    public final native String getValue() /*-{
		return this.value;
    }-*/;
}
