package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria;

import com.smartgwt.client.data.AdvancedCriteria;
import com.smartgwt.client.data.Criterion;
import com.smartgwt.client.types.OperatorId;

public final class GenerateJSONFilterCriteriaGwtTestHelper {

    private static final String RANGE_POSITION_END = "end";
    private static final String RANGE_POSITION_START = "start";
    private static final String RELATIVE_DATE_CONSTRUCTOR = "RelativeDate";
    private static final String FIELDNAME_COMPLETENESS_LEVEL = "COMPLETENESS_LEVEL";
    private static final String FIELDNAME_UK_MKT_RELEVANCE_LEVEL = "UK_MKT_RELEVANCE_LEVEL";
    private static final String FIELDNAME_ISBN13 = "ISBN13";
    private static final String FIELDNAME_PUBLISHER_PUBLICATION_DATE = "PUBLISHER_PUBLICATION_DATE";
    private static final String FIELDNAME_UK_ALL_DISTRIBUTOR_NAME_STAR = "UK_ALL_DISTRIBUTOR_NAME_*";
    private static final String FIELDNAME_PUBLISHER_ORG_ID = "PUBLISHER_ORG_ID";
    private static final String FIELDNAME_SUBSCRIBER_ORG_ID = "SUBSCRIBER_ORG_ID";
    private static final String FIELDNAME_IN_PRODUCT_FLAG = "IN_PRODUCT_FLAG";
    private static final String FIELDNAME_PUBLISHER_ANNOUNCEMENT_DATE = "PUBLISHER_ANNOUNCEMENT_DATE";
    private static final String FIELDNAME_PUBLISHING_STATUS_CODE = "PUBLISHING_STATUS_CODE";
    private static final String FIELDNAME_PRODUCT_FORM_CODE = "PRODUCT_FORM_CODE";
    private static final String FIELDNAME_UK_NBD_LOCAL_PUBLICATION_DATE = "UK_NBD_LOCAL_PUBLICATION_DATE";
    private static final String FIELDNAME_ONIX_AUDIENCE_CODE = "ONIX_AUDIENCE_CODE_*";
    private static final String FIELDNAME_PUBLISHER_NAME = "PUBLISHER_NAME";
    private static final String FIELDNAME_THEMA_SUBJECT_CODE = "THEMA_SUBJECT_CODE_*";

    public static AdvancedCriteria getCriteriaRootForCUSTOMER1() {

        final AdvancedCriteria publisherAnnouncementDate = getPublisherAnnouncementDateNotBlankorPlus1Day();

        final Criterion ndbLocalPublicationDate = createDateRangeCriterion(FIELDNAME_UK_NBD_LOCAL_PUBLICATION_DATE,
                                                                           OperatorId.IBETWEEN_INCLUSIVE,
                                                                           "$today",
                                                                           "+370d[+0D]");

        final Criterion publishingStatusCode = getPublisherStatusCode();

        final Criterion subscriberOrPublisherOrgId = getSubscriberPublisherOrgIdCriterionCUSTOMER1();

        final Criterion notFormCode = getNotFormCodeCriterionCUSTOMER1();

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           publisherAnnouncementDate, //
                                                                           createISBN13IsNotBlankCriterion(), //
                                                                           createMarketRelevanceGreaterLessThan2(), //
                                                                           new Criterion(FIELDNAME_COMPLETENESS_LEVEL,
                                                                                         OperatorId.GREATER_OR_EQUAL,
                                                                                         "3"), //

                                                                           ndbLocalPublicationDate, //
                                                                           publishingStatusCode, //
                                                                           subscriberOrPublisherOrgId, //
                                                                           notFormCode //
                                                                   }//
        );
        criteriaRoot.setStrictSQLFiltering(null);

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForCUSTOMER2() {

        final AdvancedCriteria publisherAnnouncementDateNotBlankOrPlus1Day =
            getPublisherAnnouncementDateNotBlankorPlus1Day();

        final Criterion publisherPublicationDate = createDateRangeCriterion(FIELDNAME_PUBLISHER_PUBLICATION_DATE,
                                                                            OperatorId.IBETWEEN_INCLUSIVE,
                                                                            "-32d[-0D]",
                                                                            "+270d[+0D]");

        final Criterion publishingStatusCode = getPublisherStatusCode();

        final Criterion subscriberOrgId = getSubscriberOrgIdCriterion(new String[] { "162152", "44793" });

        final Criterion notFormCode = getNotFormCodeCriterionCUSTOMER2();

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           publisherAnnouncementDateNotBlankOrPlus1Day, //
                                                                           publisherPublicationDate, //
                                                                           publishingStatusCode, //
                                                                           subscriberOrgId, //
                                                                           notFormCode //
                                                                   }//
        );
        criteriaRoot.setStrictSQLFiltering(null);

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForCUSTOMER3() {

        final AdvancedCriteria publisherAnnouncementDateNotBlankOrPlus1Day =
            getPublisherAnnouncementDateNotBlankorPlus1Day();

        final Criterion nbdLocalPublicationDate = createDateRangeCriterion(FIELDNAME_UK_NBD_LOCAL_PUBLICATION_DATE,
                                                                           OperatorId.IBETWEEN_INCLUSIVE,
                                                                           "$today",
                                                                           "+112d[+0D]");

        final Criterion notFormCode = getNotFormCodeCriterionCUSTOMER3();

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           publisherAnnouncementDateNotBlankOrPlus1Day, //
                                                                           createISBN13IsNotBlankCriterion(), //
                                                                           createMarketRelevanceGreaterLessThan2(), //
                                                                           nbdLocalPublicationDate, //
                                                                           new Criterion(FIELDNAME_UK_ALL_DISTRIBUTOR_NAME_STAR,
                                                                                         OperatorId.NOT_BLANK), //
                                                                           new Criterion(FIELDNAME_PRODUCT_FORM_CODE,
                                                                                         OperatorId.ISTARTS_WITH,
                                                                                         "B"), //
                                                                           notFormCode //
                                                                   }//
        );
        criteriaRoot.setStrictSQLFiltering(null);

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForCUSTOMER4() {

        final AdvancedCriteria publisherAnnouncementDateNotBlankOrPlus1Day =
            getPublisherAnnouncementDateNotBlankorPlus1Day();

        final Criterion publisherPublicationDate = createDateRangeCriterion(FIELDNAME_PUBLISHER_PUBLICATION_DATE,
                                                                            OperatorId.IBETWEEN_INCLUSIVE,
                                                                            "-30d[-0D]",
                                                                            "+360d[+0D]");

        final Criterion publishingStatusCode = getPublisherStatusCode();

        final Criterion subscriberOrgId = getSubscriberOrgIdCriterion(new String[] { "162152", "44793" });

        final Criterion notFormCode = getNotFormCodeCriterionCUSTOMER2();

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           publisherAnnouncementDateNotBlankOrPlus1Day, //
                                                                           publisherPublicationDate, //
                                                                           publishingStatusCode, //
                                                                           subscriberOrgId, //
                                                                           notFormCode //
                                                                   } //
        );
        criteriaRoot.setStrictSQLFiltering(null);

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForPOC1() {

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY() //
                                                                   } //
        );

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForPOC2() {

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           new Criterion(FIELDNAME_PRODUCT_FORM_CODE,
                                                                                         OperatorId.EQUALS,
                                                                                         "BC"), //
                                                                           new Criterion(FIELDNAME_ONIX_AUDIENCE_CODE,
                                                                                         OperatorId.EQUALS,
                                                                                         "04") //
                                                                   } //
        );

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForPOC3() {

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           new Criterion(FIELDNAME_PRODUCT_FORM_CODE,
                                                                                         OperatorId.EQUALS,
                                                                                         "BB"), //
                                                                           new Criterion(FIELDNAME_ONIX_AUDIENCE_CODE,
                                                                                         OperatorId.EQUALS,
                                                                                         "01") //
                                                                   } //
        );

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForPOC4() {

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           new Criterion(FIELDNAME_PUBLISHER_NAME,
                                                                                         OperatorId.ICONTAINS,
                                                                                         "Anness") //
                                                                   } //
        );

        return criteriaRoot;
    }

    public static AdvancedCriteria getCriteriaRootForPOC5() {

        final AdvancedCriteria criteriaRoot = new AdvancedCriteria(OperatorId.AND,
                                                                   new Criterion[] { //
                                                                           inProductFlagIsY(), //
                                                                           new Criterion(FIELDNAME_THEMA_SUBJECT_CODE,
                                                                                         OperatorId.EQUALS,
                                                                                         "AGA") //
                                                                   } //
        );

        return criteriaRoot;
    }

    private static Criterion getPublisherStatusCode() {

        final Criterion publishingStatusCode =
            new Criterion(FIELDNAME_PUBLISHING_STATUS_CODE, OperatorId.IN_SET, new String[] { "02", "04" });
        return publishingStatusCode;
    }

    private static AdvancedCriteria getPublisherAnnouncementDateNotBlankorPlus1Day() {

        final RelativeDateJSCriterionObject publisherRelativeDate = RelativeDateJSCriterionObject.createObject().cast();
        publisherRelativeDate.setFieldName(FIELDNAME_PUBLISHER_ANNOUNCEMENT_DATE);
        publisherRelativeDate.setOperator(OperatorId.LESS_OR_EQUAL.getValue());

        final RelativeDateJSObject relativeDate = RelativeDateJSObject.createObject().cast();
        relativeDate.setConstructor(RELATIVE_DATE_CONSTRUCTOR);
        relativeDate.setValue("+1d");

        publisherRelativeDate.setValue(relativeDate);

        final AdvancedCriteria publisherAnnouncementDateNotBlankOrPlus1Day =
            new AdvancedCriteria(OperatorId.OR,
                                 new Criterion[] {
                                         new Criterion(FIELDNAME_PUBLISHER_ANNOUNCEMENT_DATE, OperatorId.IS_BLANK),
                                         new Criterion(publisherRelativeDate) });
        return publisherAnnouncementDateNotBlankOrPlus1Day;
    }

    private static Criterion inProductFlagIsY() {

        return new Criterion(FIELDNAME_IN_PRODUCT_FLAG, OperatorId.EQUALS, "Y");
    }

    private static Criterion getSubscriberPublisherOrgIdCriterionCUSTOMER1() {

        final Criterion subsriberOrgId = new Criterion(FIELDNAME_SUBSCRIBER_ORG_ID,
                                                       OperatorId.IN_SET,
                                                       new String[] { "186418", "73846", "73809", "166576", "87535",
                                                               "3865", "127855", "146862", "96859", "117448", "127931",
                                                               "162152" });

        final Criterion publishingOrgId =
            new Criterion(FIELDNAME_PUBLISHER_ORG_ID,
                          OperatorId.IN_SET,
                          new String[] { "44793", "87292", "55652", "68139", "110326", "81848" });
        final Criterion subscriberOrPublisherOrgId =
            new Criterion(OperatorId.OR, new Criterion[] { subsriberOrgId, publishingOrgId });
        return subscriberOrPublisherOrgId;
    }

    private static Criterion createDateRangeCriterion(final String fieldName,
                                                      final OperatorId operatorId,
                                                      final String start,
                                                      final String end) {

        final RelativeDateAsStartRangeJSObject relativeDateStart =
            RelativeDateAsStartRangeJSObject.createObject().cast();

        relativeDateStart.setConstructor(RELATIVE_DATE_CONSTRUCTOR);
        relativeDateStart.setRangePosition(RANGE_POSITION_START);
        relativeDateStart.setValue(start);

        final RelativeDateAsEndRangeJSObject relativeDateEnd = RelativeDateAsEndRangeJSObject.createObject().cast();

        relativeDateEnd.setConstructor(RELATIVE_DATE_CONSTRUCTOR);
        relativeDateEnd.setRangePosition(RANGE_POSITION_END);
        relativeDateEnd.setValue(end);

        final InbetweenDatesJSCriterionObject localPubDate = InbetweenDatesJSCriterionObject.createObject().cast();

        localPubDate.setFieldName(fieldName);
        localPubDate.setOperator(operatorId.getValue());
        localPubDate.setStart(relativeDateStart);
        localPubDate.setEnd(relativeDateEnd);

        final Criterion localPubDateCriterion = new Criterion(localPubDate);

        return localPubDateCriterion;
    }

    private static Criterion getNotFormCodeCriterionCUSTOMER1() {

        final Criterion productFormCodeEqualsDG = new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.EQUALS, "DG");
        final Criterion productFormCodeEqualsWX = new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.EQUALS, "WX");
        final Criterion productFormCodeStartsWithV =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "V");
        final Criterion productFormCodeStartsWithX =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "X");
        final Criterion productFormCodeStartsWithZ =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "Z");
        final Criterion criterion = new Criterion(OperatorId.NOT,
                                                  new Criterion[] { productFormCodeEqualsDG, productFormCodeEqualsWX,
                                                          productFormCodeStartsWithV, productFormCodeStartsWithX,
                                                          productFormCodeStartsWithZ });
        return criterion;
    }

    private static Criterion getSubscriberOrgIdCriterion(final String[] values) {

        final Criterion subsriberOrgId = new Criterion(FIELDNAME_SUBSCRIBER_ORG_ID, OperatorId.IN_SET, values);

        return subsriberOrgId;
    }

    private static Criterion getNotFormCodeCriterionCUSTOMER2() {

        final Criterion productFormCodeEqualsDG = new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.EQUALS, "DG");
        final Criterion productFormCodeEqualsWX = new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.EQUALS, "WV");
        final Criterion productFormCodeStartsWithV =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "V");
        final Criterion productFormCodeStartsWithX =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "X");
        final Criterion productFormCodeStartsWithZ =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "Z");
        final Criterion supplimentaryRecordCodeEqualsY = new Criterion("SUPPLEMENTARY_RECORD", OperatorId.EQUALS, "Y");
        final Criterion criterion = new Criterion(OperatorId.NOT,
                                                  new Criterion[] { productFormCodeEqualsDG, productFormCodeEqualsWX,
                                                          productFormCodeStartsWithV, productFormCodeStartsWithX,
                                                          productFormCodeStartsWithZ, supplimentaryRecordCodeEqualsY });
        return criterion;
    }

    private static Criterion getNotFormCodeCriterionCUSTOMER3() {

        final Criterion productFormCodeEqualsB2 =
            new Criterion(FIELDNAME_PRODUCT_FORM_CODE, OperatorId.ISTARTS_WITH, "B2");
        final Criterion criterion = new Criterion(OperatorId.NOT, new Criterion[] { productFormCodeEqualsB2 });
        return criterion;
    }

    private static Criterion createMarketRelevanceGreaterLessThan2() {

        return new Criterion(FIELDNAME_UK_MKT_RELEVANCE_LEVEL, OperatorId.GREATER_OR_EQUAL, "2");
    }

    private static Criterion createISBN13IsNotBlankCriterion() {

        return new Criterion(FIELDNAME_ISBN13, OperatorId.NOT_BLANK);
    }

    private GenerateJSONFilterCriteriaGwtTestHelper() {
    }

}
