package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.shared;

import java.util.LinkedHashMap;

/**
 * This map defines the valid data types that a field can be. They should be
 * based on SmartGWT DataSource data types that can drive widgets like the
 * FilterBuilder.
 * 
 * https://www.smartclient.com/smartgwtee-release/javadoc/com/smartgwt/client/types/FieldType.html
 * 
 * We do not support all values, but be careful if attempting to deviate from
 * the supported list.
 */
public enum DataType {

                      // Keep in label order to automatically sort alphabetical on client
                      BOOLEAN("boolean", "Boolean"),

                      FLOAT("float", "Decimal"),

                      DATE("date", "Date"),

                      INTEGER("integer", "Integer"),

                      TEXT("text", "Text");

    // This is used to drive the operator types in {@link ProductFilterBuilder} see
    // {@link ProductFilterFieldDTO}
    private String dataTypeName;
    private String label;

    // Static map for use in SmartGWT components
    private static LinkedHashMap<String, String> map;
    private static LinkedHashMap<String, DataType> objectMap;
    static {
        map = new LinkedHashMap<String, String>();
        objectMap = new LinkedHashMap<String, DataType>();
        for (DataType type : values()) {
            map.put(type.name(), type.getLabel());
            objectMap.put(type.getDataTypeName(), type);
        }
    }

    private DataType(final String name, final String label) {
        this.dataTypeName = name;
        this.label = label;
    }

    public String getDataTypeName() {
        return dataTypeName;
    }

    public String getLabel() {
        return label;
    }

    /**
     * For use in SmartGWT widgets (like dropdowns)
     * 
     * @return LinkedHashMap the map of values
     */
    public static LinkedHashMap<String, String> getValueDisplayMap() {
        // Return a new instance of the values in the map
        return new LinkedHashMap<String, String>(map);
    }
}
