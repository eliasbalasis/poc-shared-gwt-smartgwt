package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.test;

public final class GwtTestBasicDataSourceSupport {

    private static final GwtTestBasicDataSourceSupport singleton = new GwtTestBasicDataSourceSupport();

    public static GwtTestBasicDataSourceSupport getDefault() {

        return singleton;
    }

    public static final String DATA_SOURCE_NAME = "fieldDS";

    public String getModuleName() {

        return "com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.BasicDataSource";
    }

    public String getRPCManagerActionURL() {

        return "/" + GwtTestBasicDataSourceSupport.getDefault().getModuleName() + ".JUnit" + "/IDACall";
    }

    private GwtTestBasicDataSourceSupport() {
    }
}
