package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.shared;

public class FieldDTO {

    public static final String FIELD_ID = "fieldId";
    public static final String FIELD_NAME = "fieldName";
    public static final String FIELD_DESCRIPTION = "fieldDescription";
    public static final String TAG_PATTERN = "tagPattern";
    public static final String DATA_TYPE = "dataType";
    public static final String FORMAT = "format";
    public static final String IS_REPEATABLE = "isRepeatable";
    public static final String MAX_REPEATS = "maxRepeats";
    public static final String IS_XML = "isXml";
    public static final String IS_ORG_FIELD = "isOrgField";
    public static final String IS_DEPRECATED = "isDeprecated";

    private String fieldId;
    // "fieldName" is a reserved element name in SmartGWT 13.0
    private String fieldName;
    private String fieldDescription;
    private String tagPattern;
    private DataType dataType;
    private String format;
    private boolean isRepeatable;
    private int maxRepeats;
    private boolean isXml;
    private boolean isOrgField;
    private boolean isDeprecated;

    public FieldDTO() {
        super();
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(final String fieldId) {
        this.fieldId = fieldId;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(final String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldDescription() {
        return fieldDescription;
    }

    public void setFieldDescription(final String fieldDescription) {
        this.fieldDescription = fieldDescription;
    }

    public String getTagPattern() {
        return tagPattern;
    }

    public void setTagPattern(final String tagPattern) {
        this.tagPattern = tagPattern;
    }

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(final DataType dataType) {
        this.dataType = dataType;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(final String format) {
        this.format = format;
    }

    public boolean getIsRepeatable() {
        return isRepeatable;
    }

    public void setIsRepeatable(final boolean repeatable) {
        this.isRepeatable = repeatable;
    }

    public int getMaxRepeats() {
        return maxRepeats;
    }

    public void setMaxRepeats(final int maxRepeats) {
        this.maxRepeats = maxRepeats;
    }

    public boolean getIsXml() {
        return isXml;
    }

    public void setIsXml(final boolean xml) {
        this.isXml = xml;
    }

    public boolean getIsOrgField() {
        return isOrgField;
    }

    public void setIsOrgField(final boolean isOrgField) {
        this.isOrgField = isOrgField;
    }

    public boolean getIsDeprecated() {
        return isDeprecated;
    }

    public void setIsDeprecated(final boolean isDeprecated) {
        this.isDeprecated = isDeprecated;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((dataType == null) ? 0 : dataType.hashCode());
        result = prime * result + ((fieldDescription == null) ? 0 : fieldDescription.hashCode());
        result = prime * result + ((fieldId == null) ? 0 : fieldId.hashCode());
        result = prime * result + ((fieldName == null) ? 0 : fieldName.hashCode());
        result = prime * result + ((format == null) ? 0 : format.hashCode());
        result = prime * result + (isDeprecated ? 1231 : 1237);
        result = prime * result + (isOrgField ? 1231 : 1237);
        result = prime * result + (isRepeatable ? 1231 : 1237);
        result = prime * result + (isXml ? 1231 : 1237);
        result = prime * result + maxRepeats;
        result = prime * result + ((tagPattern == null) ? 0 : tagPattern.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        FieldDTO other = (FieldDTO) obj;
        if (dataType == null) {
            if (other.dataType != null)
                return false;
        } else if (!dataType.equals(other.dataType))
            return false;
        if (fieldDescription == null) {
            if (other.fieldDescription != null)
                return false;
        } else if (!fieldDescription.equals(other.fieldDescription))
            return false;
        if (fieldId == null) {
            if (other.fieldId != null)
                return false;
        } else if (!fieldId.equals(other.fieldId))
            return false;
        if (fieldName == null) {
            if (other.fieldName != null)
                return false;
        } else if (!fieldName.equals(other.fieldName))
            return false;
        if (format == null) {
            if (other.format != null)
                return false;
        } else if (!format.equals(other.format))
            return false;
        if (isDeprecated != other.isDeprecated)
            return false;
        if (isOrgField != other.isOrgField)
            return false;
        if (isRepeatable != other.isRepeatable)
            return false;
        if (isXml != other.isXml)
            return false;
        if (maxRepeats != other.maxRepeats)
            return false;
        if (tagPattern == null) {
            if (other.tagPattern != null)
                return false;
        } else if (!tagPattern.equals(other.tagPattern))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "FieldDTO [fieldId=" + fieldId + ", fieldName=" + fieldName + ", fieldDescription=" + fieldDescription +
            ", tagPattern=" + tagPattern + ", dataType=" + dataType + ", format=" + format + ", isRepeatable=" +
            isRepeatable + ", maxRepeats=" + maxRepeats + ", isXml=" + isXml + ", isOrgField=" + isOrgField +
            ", isDeprecated=" + isDeprecated + "]";
    }
}
