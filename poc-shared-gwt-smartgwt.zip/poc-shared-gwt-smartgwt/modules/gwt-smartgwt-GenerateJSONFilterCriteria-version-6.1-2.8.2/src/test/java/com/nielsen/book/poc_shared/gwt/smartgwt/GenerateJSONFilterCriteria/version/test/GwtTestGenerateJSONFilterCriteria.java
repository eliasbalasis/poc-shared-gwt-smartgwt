package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test;

import com.google.gwt.junit.client.GWTTestCase;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputEncoding;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputType;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputVersion;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test.criteria.GenerateJSONFilterCriteriaGwtTestHelper;
import com.smartgwt.client.SmartGwtEntryPoint;
import com.smartgwt.client.data.AdvancedCriteria;

public class GwtTestGenerateJSONFilterCriteria extends GWTTestCase {

    @Override
    public String getModuleName() {

        return GwtTestGenerateJSONFilterCriteriaSupport.getDefault().getModuleName();
    }

    @Override
    public void gwtSetUp() {

        new SmartGwtEntryPoint().onModuleLoad();
    }

    @Override
    protected void gwtTearDown() throws Exception {
    }

    @Override
    protected void reportUncaughtException(final Throwable ex) {
    }

    public void testGenerateJSONFilterCriteriaInitial() {

        AdvancedCriteria criteria;
        String input;

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER1();
        input = criteria.toJSON();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER1,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER1();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER1,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER2();
        input = criteria.toJSON();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER2,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER2();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER2,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER3();
        input = criteria.toJSON();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER3,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER3();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER3,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER4();
        input = criteria.toJSON();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER4,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForCUSTOMER4();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.CUSTOMER4,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);
    }

    public void testGenerateJSONFilterCriteriaCaptured() {

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.WBK2428,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_WBK2428,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.EQUALSFIXEDDATE,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_EQUALSFIXEDDATE_TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputEncoding.TO_JSON,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.EQUALSFIXEDDATE,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_EQUALSFIXEDDATE_AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.WBK2745A,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_WBK2745A,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.WBK2745B,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_WBK2745B,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.GREATERTHANOREQUALTOFIXEDDATE,
                                                                            GwtTestGenerateJSONFilterCriteriaSupport.INPUT_CAPTURED_GREATERTHANOREQUALTOFIXEDDATE,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);
    }

    public void testGenerateJSONFilterCriteriaPOC() {

        AdvancedCriteria criteria;
        String input;

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForPOC1();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.PRODUCT_FILTERS_POC_1,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForPOC2();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.PRODUCT_FILTERS_POC_2,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForPOC3();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.PRODUCT_FILTERS_POC_3,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForPOC4();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.PRODUCT_FILTERS_POC_4,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);

        criteria = GenerateJSONFilterCriteriaGwtTestHelper.getCriteriaRootForPOC5();
        input = criteria.asString();
        GwtTestGenerateJSONFilterCriteriaSupport.getDefault()
                                                .generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType.PRODUCT_FILTERS_POC_5,
                                                                            input,
                                                                            GenerateJSONFilterCriteriaInputEncoding.AS_STRING,
                                                                            GenerateJSONFilterCriteriaInputVersion.SMARTGWT_6_1_GWT_2_8_2);
    }
}
