package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.exec.environment.EnvironmentUtils;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.MessageFormatter;

import com.isomorphic.webdriver.SmartClientFirefoxDriver;
import com.isomorphic.webdriver.SmartClientRemoteWebDriver;
import com.isomorphic.webdriver.SmartClientWebDriver;
import com.nielsen.book.poc_shared.tools.selenium.SeleniumGridSupport;
import com.nielsen.book.poc_shared.tools.selenium.SeleniumGridVersion;
import com.nielsen.book.poc_shared.tools.selenium.SeleniumSupport;

public class SeleniumTest extends AbstractSeleniumTest<SmartClient_6_1_WebDriverContainer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SeleniumTest.class);

    @Override
    protected Iterable<Capabilities> capabilitiesList() {

        // "Chrome" browser version (53.0.2785.143)
        // bundled with "Selenium" of "SmartGWT 6.1"
        // is not incompatible with "Nielsen Client Platform"
        //
        // However,
        // "Firefox" browser version (47.0.1)
        // bundled with "Selenium" of "SmartGWT 6.1"
        // is compatible with "Nielsen Client Platform"
        //
        final DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setJavascriptEnabled(true);
        capabilities.setPlatform(Platform.LINUX);
        return Arrays.asList(capabilities);
    }

    @Override
    protected SmartClient_6_1_WebDriverContainer webDriverContainer(final Capabilities capabilities) throws Throwable {

        final SmartClientWebDriver webDriver;

        if (SeleniumSupport.getDefault().forceDriverExecutable()) {

            if (capabilities.getBrowserName().equals(BrowserType.FIREFOX)) {

                final Map<String, String> environment = EnvironmentUtils.getProcEnvironment();

                // "Selenium Driver" executable
                // https://github.com/mozilla/geckodriver/releases/
                final String firefoxDriverPath = environment.get(SeleniumSupport.VAR_FIREFOX_DRIVER_PATH_2_53_1);
                System.setProperty("webdriver.gecko.driver", firefoxDriverPath);
                LOGGER.info("webdriver.gecko.driver={}", firefoxDriverPath);

                // Requires "Firefox" 47.0.1
                // same as the remote "Firefox" browser version
                // bundled with "Selenium" of "SmartGWT 6.1"
                // https://ftp.mozilla.org/pub/firefox/releases/47.0.1/firefox-47.0.1.win32.sdk.zip
                // https://ftp.mozilla.org/pub/firefox/releases/47.0.1/firefox-47.0.1.win64.sdk.zip
                // https://ftp.mozilla.org/pub/firefox/releases/47.0.1/firefox-47.0.1.linux-i686.sdk.tar.bz2
                // https://ftp.mozilla.org/pub/firefox/releases/47.0.1/firefox-47.0.1.linux-x86_64.sdk.tar.bz2
                // https://ftp.mozilla.org/pub/firefox/releases/47.0.1/firefox-47.0.1.mac-x86_64.sdk.tar.bz2
                //
                // Requires "Selenium Driver" executable version 0.29.1
                //
                if (environment.containsKey(SeleniumSupport.VAR_FIREFOX_BINARY_PATH_2_53_1)) {

                    final String pathToFirefoxBinary = environment.get(SeleniumSupport.VAR_FIREFOX_BINARY_PATH_2_53_1);
                    LOGGER.info("pathToFirefoxBinary={}", pathToFirefoxBinary);
                    final FirefoxBinary binary = new FirefoxBinary(new File(pathToFirefoxBinary));
                    webDriver = new SmartClientFirefoxDriver(binary);

                } else {

                    webDriver = null;
                }

            } else {

                webDriver = null;
            }

        } else {

            // Connect to Selenium Grid
            final URL remoteAddress =
                SeleniumGridSupport.getDefault().getSeleniumGridURL(SeleniumGridVersion.SELENIUM_2_53_1);
            if (remoteAddress == null) {
                final String message =
                    MessageFormatter.arrayFormat("The Selenium Grid coordinates could not be discovered for capabilities {} ",
                                                 new Object[] { capabilities })
                                    .getMessage();
                throw new RuntimeException(message);
            }
            LOGGER.info("Connecting to Selenium Grid at {} with {}", remoteAddress, capabilities);
            webDriver = new SmartClientRemoteWebDriver(new RemoteWebDriver(remoteAddress, capabilities));
            LOGGER.info("Connected to Selenium Grid at {}", remoteAddress);
        }

        final SmartClient_6_1_WebDriverContainer webDriverContainer = new SmartClient_6_1_WebDriverContainer(webDriver);
        return webDriverContainer;
    }

    @Override
    protected void configureWebDriver(final Capabilities capabilities,
                                      final SmartClient_6_1_WebDriverContainer webDriverContainer) {

        webDriverContainer.setBaseUrl(BASE_URL);
    }

    @Override
    protected void navigate(final SmartClient_6_1_WebDriverContainer webDriverContainer) {

        webDriverContainer.navigateToPath(PATH);
    }

    @Test
    public void run() throws Throwable {

        main();
    }
}
