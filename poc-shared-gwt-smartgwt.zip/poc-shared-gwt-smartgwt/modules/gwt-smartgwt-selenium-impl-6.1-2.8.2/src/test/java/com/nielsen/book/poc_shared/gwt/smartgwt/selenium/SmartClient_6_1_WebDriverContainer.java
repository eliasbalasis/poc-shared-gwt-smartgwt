package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

import com.isomorphic.webdriver.SmartClientWebDriver;

public class SmartClient_6_1_WebDriverContainer implements WebDriverContainer {

    private final SmartClientWebDriver webDriver;

    @Override
    public void quit() {

        this.webDriver.quit();
    }

    @Override
    public void setBaseUrl(final String url) {

        this.webDriver.setBaseUrl(url);
    }

    @Override
    public void navigateToPath(final String path) {

        this.webDriver.get(path);
    }

    public SmartClient_6_1_WebDriverContainer(final SmartClientWebDriver webDriver) {

        this.webDriver = webDriver;
    }
}
