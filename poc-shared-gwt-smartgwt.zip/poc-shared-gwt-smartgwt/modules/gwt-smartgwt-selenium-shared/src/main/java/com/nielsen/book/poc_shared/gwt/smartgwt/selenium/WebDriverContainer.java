package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

public interface WebDriverContainer {

    void quit();

    void setBaseUrl(String url);

    void navigateToPath(String path);
}
