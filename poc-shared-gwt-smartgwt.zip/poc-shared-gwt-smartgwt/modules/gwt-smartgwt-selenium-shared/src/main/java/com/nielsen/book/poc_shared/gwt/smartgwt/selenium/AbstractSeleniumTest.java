package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

import org.openqa.selenium.Capabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.MessageFormatter;

public abstract class AbstractSeleniumTest<WEBDRIVER_CONTAINER extends WebDriverContainer> {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    protected static final String BASE_URL = "http://google.com";
    protected static final String PATH = "/search";

    protected abstract Iterable<Capabilities> capabilitiesList();

    protected abstract WEBDRIVER_CONTAINER webDriverContainer(Capabilities capabilities) throws Throwable;

    protected abstract void configureWebDriver(Capabilities capabilities, WEBDRIVER_CONTAINER webDriverContainer);

    protected abstract void navigate(WEBDRIVER_CONTAINER webDriverContainer);

    protected final void main() throws Throwable {

        final Iterable<Capabilities> capabilitiesList = capabilitiesList();

        for (Capabilities capabilities : capabilitiesList) {

            final WEBDRIVER_CONTAINER webDriverContainer = webDriverContainer(capabilities);

            // Check WebDriver
            final boolean webDriverContainerNotCreated;
            if (webDriverContainer == null) {
                webDriverContainerNotCreated = true;
            } else {
                webDriverContainerNotCreated = false;
            }
            if (webDriverContainerNotCreated) {
                final String message =
                    MessageFormatter.arrayFormat("A WebDriver instance could not be created for capabilities {} ",
                                                 new Object[] { capabilities })
                                    .getMessage();
                throw new RuntimeException(message);
            }

            // Run
            try {

                configureWebDriver(capabilities, webDriverContainer);

                navigate(webDriverContainer);

            } catch (Throwable cause) {

                LOGGER.error("Failed to execute UI test", cause);
                throw cause;

            } finally {

                // Exit browser instance
                if (webDriverContainer != null) {
                    LOGGER.info("Exiting browser...");
                    webDriverContainer.quit();
                    LOGGER.info("Exited browser");
                }
            }
        }
    }
}
