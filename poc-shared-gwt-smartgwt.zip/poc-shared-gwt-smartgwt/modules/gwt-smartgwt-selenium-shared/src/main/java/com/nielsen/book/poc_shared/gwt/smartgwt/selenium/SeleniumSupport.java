package com.nielsen.book.poc_shared.gwt.smartgwt.selenium;

public final class SeleniumSupport {

    public static final String VAR_CHROME_DRIVER_PATH_2_53_1 = "SELENIUM_CHROME_DRIVER_PATH_2_53_1";
    public static final String VAR_CHROME_BINARY_PATH_2_53_1 = "SELENIUM_CHROME_BINARY_PATH_2_53_1";

    public static final String VAR_FIREFOX_DRIVER_PATH_2_53_1 = "SELENIUM_FIREFOX_DRIVER_PATH_2_53_1";
    public static final String VAR_FIREFOX_BINARY_PATH_2_53_1 = "SELENIUM_FIREFOX_BINARY_PATH_2_53_1";

    public static final String VAR_EDGE_DRIVER_PATH_4_1_1 = "SELENIUM_EDGE_DRIVER_PATH_4_1_1";

    public static final String VAR_CHROME_DRIVER_PATH_3_14_0 = "SELENIUM_CHROME_DRIVER_PATH_3_14_0";
    public static final String VAR_CHROME_BINARY_PATH_3_14_0 = "SELENIUM_CHROME_BINARY_PATH_3_14_0";

    public static final String VAR_CHROME_DRIVER_PATH_3_141_59 = "SELENIUM_CHROME_DRIVER_PATH_3_141_59";
    public static final String VAR_CHROME_BINARY_PATH_3_141_59 = "SELENIUM_CHROME_BINARY_PATH_3_141_59";

    private static final SeleniumSupport singleton = new SeleniumSupport();

    public static SeleniumSupport getDefault() {

        return singleton;
    }

    private SeleniumSupport() {
    }
}
