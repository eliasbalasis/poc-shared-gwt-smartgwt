package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared;

public enum GenerateJSONFilterCriteriaInputType {
                                                 CUSTOMER1,
                                                 CUSTOMER2,
                                                 CUSTOMER3,
                                                 CUSTOMER4,
                                                 WBK2428,
                                                 EQUALSFIXEDDATE,
                                                 GREATERTHANOREQUALTOFIXEDDATE,
                                                 PRODUCT_FILTERS_POC_1,
                                                 PRODUCT_FILTERS_POC_2,
                                                 PRODUCT_FILTERS_POC_3,
                                                 PRODUCT_FILTERS_POC_4,
                                                 PRODUCT_FILTERS_POC_5,
                                                 WBK2745A,
                                                 WBK2745B;
}
