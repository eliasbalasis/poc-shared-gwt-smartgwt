package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared;

public enum GenerateJSONFilterCriteriaInputVersion {
                                                    SMARTGWT_6_1_GWT_2_8_2,
                                                    SMARTGWT_13_0_GWT_2_9_0
}
