package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface GenerateJSONFilterCriteriaAsync {

    void generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType inputType,
                                    String input,
                                    GenerateJSONFilterCriteriaInputEncoding inputEncoding,
                                    GenerateJSONFilterCriteriaInputVersion inputVersion,
                                    AsyncCallback<Void> callback);
}
