package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared;

public enum GenerateJSONFilterCriteriaInputEncoding {
                                                    TO_JSON,
                                                    AS_STRING
}
