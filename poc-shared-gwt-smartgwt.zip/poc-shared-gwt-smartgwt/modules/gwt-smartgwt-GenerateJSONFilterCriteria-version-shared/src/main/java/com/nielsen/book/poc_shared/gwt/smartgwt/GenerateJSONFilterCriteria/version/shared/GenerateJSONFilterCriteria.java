package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("generateJSONFilterCriteria")
public interface GenerateJSONFilterCriteria extends RemoteService {

    void generateJSONFilterCriteria(GenerateJSONFilterCriteriaInputType inputType,
                                    String input,
                                    GenerateJSONFilterCriteriaInputEncoding inputEncoding,
                                    GenerateJSONFilterCriteriaInputVersion inputVersion);
}
