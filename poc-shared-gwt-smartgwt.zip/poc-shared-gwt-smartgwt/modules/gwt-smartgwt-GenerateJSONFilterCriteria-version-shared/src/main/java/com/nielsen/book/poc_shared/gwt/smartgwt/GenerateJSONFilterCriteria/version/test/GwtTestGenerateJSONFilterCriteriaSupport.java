package com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.test;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteria;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaAsync;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputEncoding;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputType;
import com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.shared.GenerateJSONFilterCriteriaInputVersion;

public final class GwtTestGenerateJSONFilterCriteriaSupport {

    private static final GwtTestGenerateJSONFilterCriteriaSupport singleton =
        new GwtTestGenerateJSONFilterCriteriaSupport();

    public static GwtTestGenerateJSONFilterCriteriaSupport getDefault() {

        return singleton;
    }

    public static final String INPUT_CAPTURED_WBK2428 = "{\n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \n" + //
        "    \"operator\":null, \n" + //
        "    \"criteria\":[\n" + //
        "        {\n" + //
        "            \"fieldName\":\"IN_PRODUCT_FLAG\", \n" + //
        "            \"operator\":\"equals\", \n" + //
        "            \"value\":\"Y\"\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \n" + //
        "            \"operator\":\"or\", \n" + //
        "            \"criteria\":[\n" + //
        "                {\n" + //
        "                    \"operator\":\"isBlank\", \n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\"\n" + //
        "                }, \n" + //
        "                {\n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\", \n" + //
        "                    \"operator\":\"lessOrEqual\", \n" + //
        "                    \"value\":{\n" + //
        "                        \"_constructor\":\"RelativeDate\", \n" + //
        "                        \"value\":\"+1d\"\n" + //
        "                    }\n" + //
        "                }\n" + //
        "            ]\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"operator\":\"notBlank\", \n" + //
        "            \"fieldName\":\"ISBN13\"\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"fieldName\":\"COMPLETENESS_LEVEL\", \n" + //
        "            \"operator\":\"greaterOrEqual\", \n" + //
        "            \"value\":\"2\"\n" + //
        "        }, \n" + "        {\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \n" + //
        "            \"operator\":\"lessOrEqual\", \n" + //
        "            \"value\":{\n" + //
        "                \"_constructor\":\"RelativeDate\", \n" + //
        "                \"value\":\"+0d\"\n" + //
        "            }\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \n" + //
        "            \"operator\":\"or\", \n" + //
        "            \"criteria\":[\n" + //
        "                {\n" + //
        "                    \"fieldName\":\"RESTRICTION_*_TYPE_CODE\", \n" + //
        "                    \"operator\":\"inSet\", \n" + //
        "                    \"value\":[\n" + //
        "                        \"06\", \n" + //
        "                        \"07\"\n" + //
        "                    ]\n" + //
        "                }, \n" + //
        "                {\n" + //
        "                    \"_constructor\":\"AdvancedCriteria\", \n" + //
        "                    \"operator\":\"not\", \n" + //
        "                    \"criteria\":[\n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PUBLISHER_ORG_ID\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"213806\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"UK_ALL_DISTRIBUTOR_ID_*\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"213806\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"iStartsWith\", \n" + //
        "                            \"value\":\"A\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"CE\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"DE\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"DF\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"DH\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"DO\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"iStartsWith\", \n" + //
        "                            \"value\":\"F\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"iStartsWith\", \n" + //
        "                            \"value\":\"P\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"WW\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"iStartsWith\", \n" + //
        "                            \"value\":\"XX\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \n" + //
        "                            \"operator\":\"iStartsWith\", \n" + //
        "                            \"value\":\"Z\"\n" + //
        "                        }, \n" + //
        "                        {\n" + //
        "                            \"fieldName\":\"RESTRICTION_*_TYPE_CODE\", \n" + //
        "                            \"operator\":\"equals\", \n" + //
        "                            \"value\":\"09\"\n" + //
        "                        }\n" + //
        "                    ]\n" + //
        "                }\n" + //
        "            ]\n" + //
        "        }\n" + //
        "    ]\n" + //
        "}";

    public static final String INPUT_CAPTURED_EQUALSFIXEDDATE_TO_JSON = "{\n" + //
        "    \"operator\":\"and\", \n" + //
        "    \"criteria\":[\n" + //
        "        {\n" + //
        "            \"fieldName\":\"IN_PRODUCT_FLAG\", \n" + //
        "            \"operator\":\"notBlank\"\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \n" + //
        "            \"operator\":\"equals\", \n" + //
        "            \"value\":\"20210805\"\n" + //
        "        }\n" + //
        "    ], \n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \n" + //
        "    \"strictSQLFiltering\":null\n" + //
        "}";

    public static final String INPUT_CAPTURED_EQUALSFIXEDDATE_AS_STRING = "{\n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \n" + //
        "    \"operator\":\"and\", \n" + //
        "    \"criteria\":[\n" + //
        "        {\n" + //
        "            \"operator\":\"notBlank\", \n" + //
        "            \"fieldName\":\"IN_PRODUCT_FLAG\"\n" + //
        "        }, \n" + //
        "        {\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \n" + //
        "            \"operator\":\"equals\", \n" + //
        "            \"value\":isc.DateUtil.createLogicalDate(2021, 7, 5)\n" + //
        "        }\n" + //
        "    ]\n" + //
        "}";

    public static final String INPUT_CAPTURED_WBK2745A = "{\r\n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "    \"operator\":null, \r\n" + //
        "    \"criteria\":[\r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"IN_PRODUCT_FLAG\", \r\n" + //
        "            \"operator\":\"equals\", \r\n" + //
        "            \"value\":\"Y\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"isBlank\", \r\n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\", \r\n" + //
        "                    \"operator\":\"lessOrEqual\", \r\n" + //
        "                    \"value\":{\r\n" + //
        "                        \"_constructor\":\"RelativeDate\", \r\n" + //
        "                        \"value\":\"+1d\"\r\n" + //
        "                    }\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"operator\":\"notBlank\", \r\n" + //
        "            \"fieldName\":\"ISBN13\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"UK_MKT_RELEVANCE_LEVEL\", \r\n" + //
        "                    \"operator\":\"greaterOrEqual\", \r\n" + //
        "                    \"value\":3\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"UK_WHOLESALERS\", \r\n" + //
        "                    \"operator\":\"iContains\", \r\n" + //
        "                    \"value\":\"GARD\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \r\n" + //
        "            \"operator\":\"lessOrEqual\", \r\n" + //
        "            \"value\":{\r\n" + //
        "                \"_constructor\":\"RelativeDate\", \r\n" + //
        "                \"value\":\"+90d\"\r\n" + //
        "            }\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"COMPLETENESS_LEVEL\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":3\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"operator\":\"notBlank\", \r\n" + //
        "            \"fieldName\":\"THEMA_SUBJECT_CODE_*\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHING_STATUS_CODE\", \r\n" + //
        "            \"operator\":\"inSet\", \r\n" + //
        "            \"value\":[\r\n" + //
        "                \"02\", \r\n" + //
        "                \"04\"\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"notBlank\", \r\n" + //
        "                    \"fieldName\":\"NBD_GBP_PRICE_RR_PRICE\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"notBlank\", \r\n" + //
        "                    \"fieldName\":\"NBD_EUR_PRICE_RR_PRICE\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"F\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"VS\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"5A\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"equals\", \r\n" + //
        "                    \"value\":\"QDX\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"not\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"E\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"S\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"V\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"X\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"Z\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"SUPPLEMENTARY_RECORD\", \r\n" + //
        "                    \"operator\":\"equals\", \r\n" + //
        "                    \"value\":\"Y\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":isc.DateUtil.createLogicalDate(2012, 0, 1)\r\n" + //
        "        }\r\n" + //
        "    ]\r\n" + //
        "}";

    public static final String INPUT_CAPTURED_WBK2745B = "{\r\n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "    \"operator\":null, \r\n" + //
        "    \"criteria\":[\r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"IN_PRODUCT_FLAG\", \r\n" + //
        "            \"operator\":\"equals\", \r\n" + //
        "            \"value\":\"Y\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"isBlank\", \r\n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PUBLISHER_ANNOUNCEMENT_DATE\", \r\n" + //
        "                    \"operator\":\"lessOrEqual\", \r\n" + //
        "                    \"value\":{\r\n" + //
        "                        \"_constructor\":\"RelativeDate\", \r\n" + //
        "                        \"value\":\"+1d\"\r\n" + //
        "                    }\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"operator\":\"notBlank\", \r\n" + //
        "            \"fieldName\":\"ISBN13\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"UK_MKT_RELEVANCE_LEVEL\", \r\n" + //
        "                    \"operator\":\"greaterOrEqual\", \r\n" + //
        "                    \"value\":3\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"UK_WHOLESALERS\", \r\n" + //
        "                    \"operator\":\"iContains\", \r\n" + //
        "                    \"value\":\"GARD\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":{\r\n" + //
        "                \"_constructor\":\"RelativeDate\", \r\n" + //
        "                \"value\":\"-90d\"\r\n" + //
        "            }\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"COMPLETENESS_LEVEL\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":3\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"operator\":\"notBlank\", \r\n" + //
        "            \"fieldName\":\"THEMA_SUBJECT_CODE_*\"\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHING_STATUS_CODE\", \r\n" + //
        "            \"operator\":\"inSet\", \r\n" + //
        "            \"value\":[\r\n" + //
        "                \"02\", \r\n" + //
        "                \"04\"\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"notBlank\", \r\n" + //
        "                    \"fieldName\":\"NBD_GBP_PRICE_RR_PRICE\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"operator\":\"notBlank\", \r\n" + //
        "                    \"fieldName\":\"NBD_EUR_PRICE_RR_PRICE\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"or\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"F\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"VS\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"5A\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"THEMA_SUBJECT_CODE_*\", \r\n" + //
        "                    \"operator\":\"equals\", \r\n" + //
        "                    \"value\":\"QDX\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "            \"operator\":\"not\", \r\n" + //
        "            \"criteria\":[\r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"E\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"S\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"V\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"X\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"PRODUCT_FORM_LIST150_CODE\", \r\n" + //
        "                    \"operator\":\"iStartsWith\", \r\n" + //
        "                    \"value\":\"Z\"\r\n" + //
        "                }, \r\n" + //
        "                {\r\n" + //
        "                    \"fieldName\":\"SUPPLEMENTARY_RECORD\", \r\n" + //
        "                    \"operator\":\"equals\", \r\n" + //
        "                    \"value\":\"Y\"\r\n" + //
        "                }\r\n" + //
        "            ]\r\n" + //
        "        }, \r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":isc.DateUtil.createLogicalDate(2012, 0, 1)\r\n" + //
        "        }\r\n" + //
        "    ]\r\n" + //
        "}";

    public static final String INPUT_CAPTURED_GREATERTHANOREQUALTOFIXEDDATE = "{\r\n" + //
        "    \"_constructor\":\"AdvancedCriteria\", \r\n" + //
        "    \"operator\":\"and\", \r\n" + //
        "    \"criteria\":[\r\n" + //
        "        {\r\n" + //
        "            \"fieldName\":\"PUBLISHER_PUBLICATION_DATE\", \r\n" + //
        "            \"operator\":\"greaterOrEqual\", \r\n" + //
        "            \"value\":isc.DateUtil.createLogicalDate(2022, 2, 11)\r\n" + //
        "        }\r\n" + //
        "    ]\r\n" + //
        "}";

    public String getModuleName() {

        return "com.nielsen.book.poc_shared.gwt.smartgwt.GenerateJSONFilterCriteria.version.GenerateJSONFilterCriteria";
    }

    public void generateJSONFilterCriteria(final GenerateJSONFilterCriteriaInputType inputType,
                                           final String input,
                                           final GenerateJSONFilterCriteriaInputEncoding inputEncoding,
                                           final GenerateJSONFilterCriteriaInputVersion inputVersion) {

        final AsyncCallback<Void> callback = new AsyncCallback<Void>() {

            @Override
            public void onSuccess(final Void response) {
            }

            @Override
            public void onFailure(final Throwable cause) {
            }
        };

        final GenerateJSONFilterCriteriaAsync async =
            (GenerateJSONFilterCriteriaAsync) GWT.create(GenerateJSONFilterCriteria.class);
        async.generateJSONFilterCriteria(inputType, input, inputEncoding, inputVersion, callback);
    }

    private GwtTestGenerateJSONFilterCriteriaSupport() {
    }
}
