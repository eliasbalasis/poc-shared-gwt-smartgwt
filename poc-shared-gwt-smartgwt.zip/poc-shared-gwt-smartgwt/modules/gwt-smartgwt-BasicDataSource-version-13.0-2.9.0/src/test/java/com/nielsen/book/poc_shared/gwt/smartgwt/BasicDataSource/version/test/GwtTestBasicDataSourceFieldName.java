package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.test;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.google.gwt.junit.client.GWTTestCase;
import com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.shared.DataType;
import com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.shared.FieldDTO;
import com.smartgwt.client.SmartGwtEntryPoint;
import com.smartgwt.client.data.DSCallback;
import com.smartgwt.client.data.DSRequest;
import com.smartgwt.client.data.DSResponse;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.rpc.RPCManager;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;

public class GwtTestBasicDataSourceFieldName extends GWTTestCase {

    @Override
    public String getModuleName() {

        return GwtTestBasicDataSourceSupport.getDefault().getModuleName();
    }

    @Override
    public void gwtSetUp() {

        new SmartGwtEntryPoint().onModuleLoad();
    }

    @Override
    protected void gwtTearDown() throws Exception {
    }

    @Override
    protected void reportUncaughtException(final Throwable ex) {
    }

    public void testRemove() {

        SC.logInfo("Acquiring dataSource...");
        final DataSource dataSource = DataSource.get(GwtTestBasicDataSourceSupport.DATA_SOURCE_NAME);
        if (dataSource == null) {
            throw new IllegalArgumentException("DataSource is null");
        }
        SC.logInfo("Acquired dataSource");

        final ListGrid grid = new ListGrid();
        grid.setDataSource(dataSource);
        final ListGridField fieldId = new ListGridField(FieldDTO.FIELD_ID, FieldDTO.FIELD_ID);
        final ListGridField fieldName = new ListGridField(FieldDTO.FIELD_NAME, FieldDTO.FIELD_NAME);
        grid.setFields(fieldId, fieldName);

        final Record record = new Record();
        record.setAttribute(FieldDTO.FIELD_ID, FieldDTO.FIELD_ID);
        record.setAttribute(FieldDTO.FIELD_NAME, FieldDTO.FIELD_NAME);
        record.setAttribute(FieldDTO.FIELD_DESCRIPTION, FieldDTO.FIELD_DESCRIPTION);
        record.setAttribute(FieldDTO.TAG_PATTERN, FieldDTO.TAG_PATTERN);
        record.setAttribute(FieldDTO.DATA_TYPE, DataType.BOOLEAN.name());
        record.setAttribute(FieldDTO.FORMAT, FieldDTO.FORMAT);
        record.setAttribute(FieldDTO.IS_REPEATABLE, true);
        record.setAttribute(FieldDTO.MAX_REPEATS, 10);
        record.setAttribute(FieldDTO.IS_XML, false);
        record.setAttribute(FieldDTO.IS_ORG_FIELD, false);
        record.setAttribute(FieldDTO.IS_DEPRECATED, false);

        final String actionURL = GwtTestBasicDataSourceSupport.getDefault().getRPCManagerActionURL();
        RPCManager.setActionURL(actionURL);
        SC.logInfo("Action URL = " + RPCManager.getActionURL());

        final AtomicInteger operationResponseCode = new AtomicInteger(-1);
        final AtomicBoolean operationResponseReceived = new AtomicBoolean(false);
        final DSCallback operationCallback = new DSCallback() {
            @Override
            public void execute(final DSResponse dsResponse, final Object data, final DSRequest dsRequest) {

                SC.logInfo("Operation response received");

                final int responseCode = dsResponse.getHttpResponseCode();
                operationResponseCode.set(responseCode);

                operationResponseReceived.set(true);
            }
        };
        SC.logInfo("Before operation");
        grid.removeData(record, operationCallback);
    }
}
