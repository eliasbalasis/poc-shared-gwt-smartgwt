package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.server;

import java.io.IOException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.isomorphic.base.InitListener;

@WebServlet
public class InitListenerServlet extends HttpServlet {

    private static final long serialVersionUID = -2616237727738827846L;

    private static final Logger LOGGER = LoggerFactory.getLogger(InitListenerServlet.class);

    private static InitListener listener;

    @Override
    public void init() throws ServletException {

        LOGGER.info("Initializing framework...");

        System.setProperty("iscUseSlf4j", "true");
        System.setProperty("iscUseLog4jConfig", "false");

        final ServletContextEvent event = new ServletContextEvent(getServletContext());
        listener = new InitListener();
        listener.contextInitialized(event);

        getServletContext().createListener(InitListener.class);
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
                                                                                               IOException {

        LOGGER.info("Processing Framework Initialization request...");

        response.setStatus(200);
        response.setContentType("application/ecmascript");
    }
}
