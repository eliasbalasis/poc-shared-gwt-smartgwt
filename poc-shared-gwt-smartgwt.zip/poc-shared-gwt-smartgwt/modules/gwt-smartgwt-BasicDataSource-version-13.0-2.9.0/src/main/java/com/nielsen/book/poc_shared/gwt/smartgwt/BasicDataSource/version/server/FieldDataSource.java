package com.nielsen.book.poc_shared.gwt.smartgwt.BasicDataSource.version.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.isomorphic.datasource.BasicDataSource;
import com.isomorphic.datasource.DSRequest;
import com.isomorphic.datasource.DSResponse;

public class FieldDataSource extends BasicDataSource {

    private static final Logger LOGGER = LoggerFactory.getLogger(FieldDataSource.class);

    private static final long serialVersionUID = -7636411137646760423L;

    @Override
    public DSResponse executeRemove(final DSRequest request) throws Exception {

        LOGGER.info("executeRemove: {}", request);

        return new DSResponse();
    }
}
