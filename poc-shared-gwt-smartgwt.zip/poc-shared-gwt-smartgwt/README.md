This is an isolated space, disconnected form the main artifacts structure and it is intended to hold experiments that can be shared with 3rd parties for troubleshooting or study.

Completed experiments can be copied back to the main artifacts structure.
